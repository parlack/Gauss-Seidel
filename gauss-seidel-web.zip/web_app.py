#!/usr/bin/env python3
"""
Aplicación web Flask para resolver sistemas de ecuaciones con Gauss-Seidel
Versión optimizada para despliegue en servidores web como GoDaddy
"""

from flask import Flask, render_template, request, jsonify
import numpy as np
import json
from solver.gauss_seidel import GaussSeidelSolver
from utils.validators import EquationValidator

app = Flask(__name__)
app.secret_key = 'gauss_seidel_web_app_2024'

# Configuración para GoDaddy
app.config['DEBUG'] = False  # Para producción

@app.route('/')
def index():
    """Página principal de la aplicación"""
    return render_template('index.html')

@app.route('/solve', methods=['POST'])
def solve_system():
    """API endpoint para resolver el sistema de ecuaciones"""
    try:
        data = request.get_json()
        
        # Extraer datos del request
        matrix_data = data.get('matrix', [])
        vector_data = data.get('vector', [])
        tolerance = float(data.get('tolerance', 1e-6))
        max_iterations = int(data.get('max_iterations', 100))
        
        # Validar entrada
        is_valid_matrix, matrix_error, A = EquationValidator.validate_matrix(matrix_data)
        if not is_valid_matrix:
            return jsonify({
                'success': False,
                'error': f'Error en matriz: {matrix_error}'
            })
        
        is_valid_vector, vector_error, b = EquationValidator.validate_vector(vector_data)
        if not is_valid_vector:
            return jsonify({
                'success': False,
                'error': f'Error en vector: {vector_error}'
            })
        
        # Intentar hacer diagonalmente dominante
        dominance_result = EquationValidator.make_diagonally_dominant(A, b)
        
        optimization_info = {
            'was_optimized': dominance_result['success'] and len(dominance_result['swaps_made']) > 0,
            'message': dominance_result['message'],
            'swaps_made': dominance_result['swaps_made'],
            'optimized_matrix': dominance_result['matrix'].tolist() if dominance_result['success'] else None,
            'optimized_vector': dominance_result['vector'].tolist() if dominance_result['success'] else None
        }
        
        # Usar la matriz optimizada si está disponible
        if dominance_result['success']:
            A = dominance_result['matrix']
            b = dominance_result['vector']
        
        # Resolver con Gauss-Seidel
        solver = GaussSeidelSolver()
        solver.tolerance = tolerance
        solver.max_iterations = max_iterations
        
        result = solver.solve(A, b)
        
        # Generar pasos detallados
        steps = solver.generate_step_by_step(A, b)
        
        # Preparar respuesta
        response_data = {
            'success': True,
            'result': {
                'solution': result['solution'].tolist(),
                'iterations': result['iterations'],
                'converged': result['converged'],
                'final_error': result['final_error'],
                'errors': result['errors'],
                'iteration_history': [iter_sol.tolist() for iter_sol in result['history']]
            },
            'steps': steps,
            'optimization': optimization_info
        }
        
        return jsonify(response_data)
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': f'Error del servidor: {str(e)}'
        })

@app.route('/validate', methods=['POST'])
def validate_input():
    """API endpoint para validar entrada sin resolver"""
    try:
        data = request.get_json()
        matrix_data = data.get('matrix', [])
        vector_data = data.get('vector', [])
        
        # Validar matriz
        is_valid_matrix, matrix_error, A = EquationValidator.validate_matrix(matrix_data)
        if not is_valid_matrix:
            return jsonify({
                'success': False,
                'error': f'Error en matriz: {matrix_error}'
            })
        
        # Validar vector
        is_valid_vector, vector_error, b = EquationValidator.validate_vector(vector_data)
        if not is_valid_vector:
            return jsonify({
                'success': False,
                'error': f'Error en vector: {vector_error}'
            })
        
        # Verificar dominancia diagonal
        dominance_result = EquationValidator.make_diagonally_dominant(A, b)
        
        return jsonify({
            'success': True,
            'message': 'Sistema válido',
            'optimization': {
                'can_optimize': dominance_result['success'],
                'message': dominance_result['message'],
                'swaps_needed': len(dominance_result['swaps_made']),
                'swaps_made': dominance_result['swaps_made']
            }
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': f'Error de validación: {str(e)}'
        })

@app.route('/example/<int:example_type>')
def get_example(example_type):
    """API endpoint para obtener ejemplos predefinidos"""
    examples = {
        1: {  # Sistema 3x3 diagonalmente dominante
            'matrix': [
                [10, -1, 2],
                [-1, 11, -1],
                [2, -1, 10]
            ],
            'vector': [6, 25, -11],
            'description': 'Sistema 3×3 diagonalmente dominante'
        },
        2: {  # Sistema que necesita reordenamiento
            'matrix': [
                [1, 8, 2],
                [2, 1, 9],
                [15, -1, 2]
            ],
            'vector': [11, 12, 16],
            'description': 'Sistema que requiere reordenamiento automático'
        },
        3: {  # Sistema 2x2
            'matrix': [
                [4, 1],
                [2, 3]
            ],
            'vector': [1, 11],
            'description': 'Sistema 2×2 simple'
        }
    }
    
    if example_type in examples:
        return jsonify({
            'success': True,
            'example': examples[example_type]
        })
    else:
        return jsonify({
            'success': False,
            'error': 'Ejemplo no encontrado'
        })

# Manejo de errores
@app.errorhandler(404)
def not_found(error):
    return render_template('error.html', error_code=404, error_message="Página no encontrada"), 404

@app.errorhandler(500)
def internal_error(error):
    return render_template('error.html', error_code=500, error_message="Error interno del servidor"), 500

if __name__ == '__main__':
    # Para desarrollo local
    app.run(debug=True, host='0.0.0.0', port=5000)
else:
    # Para producción en GoDaddy
    application = app  # GoDaddy espera una variable llamada 'application'
