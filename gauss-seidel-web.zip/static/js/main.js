// JavaScript para Gauss-Seidel Web App

// Variables globales
let currentSystemSize = 3;
let iterationData = [];
let currentIteration = 0;
let convergenceChart = null;

// Inicialización al cargar la página
document.addEventListener('DOMContentLoaded', function() {
    initializeSystem();
    setupEventListeners();
});

// Inicializar sistema con tamaño por defecto
function initializeSystem() {
    currentSystemSize = parseInt(document.getElementById('systemSize').value);
    generateMatrixInputs();
    generateVectorInputs();
    showStatus('Listo para resolver sistemas', 'info');
}

// Configurar event listeners
function setupEventListeners() {
    // Cambio de tamaño del sistema
    document.getElementById('systemSize').addEventListener('change', function() {
        currentSystemSize = parseInt(this.value);
        generateMatrixInputs();
        generateVectorInputs();
        clearResults();
    });
    
    // Validación en tiempo real
    document.addEventListener('input', function(e) {
        if (e.target.classList.contains('matrix-input') || e.target.classList.contains('vector-input')) {
            validateInput(e.target);
        }
    });
    
    // Tecla Enter para resolver
    document.addEventListener('keypress', function(e) {
        if (e.key === 'Enter' && (e.target.classList.contains('matrix-input') || e.target.classList.contains('vector-input'))) {
            solveSystem();
        }
    });
}

// Generar inputs para la matriz
function generateMatrixInputs() {
    const container = document.getElementById('matrixInputs');
    container.innerHTML = '';
    container.className = `matrix-grid size-${currentSystemSize}`;
    
    for (let i = 0; i < currentSystemSize; i++) {
        for (let j = 0; j < currentSystemSize; j++) {
            const input = document.createElement('input');
            input.type = 'text';
            input.className = 'form-control matrix-input';
            input.placeholder = `a${i+1}${j+1}`;
            input.id = `matrix_${i}_${j}`;
            container.appendChild(input);
        }
    }
}

// Generar inputs para el vector
function generateVectorInputs() {
    const container = document.getElementById('vectorInputs');
    container.innerHTML = '';
    
    for (let i = 0; i < currentSystemSize; i++) {
        const input = document.createElement('input');
        input.type = 'text';
        input.className = 'form-control vector-input mb-2';
        input.placeholder = `b${i+1}`;
        input.id = `vector_${i}`;
        container.appendChild(input);
    }
}

// Validar entrada individual
function validateInput(input) {
    const value = input.value.trim();
    
    if (value === '') {
        input.classList.remove('invalid');
        return;
    }
    
    const numValue = parseFloat(value);
    if (isNaN(numValue) || !isFinite(numValue)) {
        input.classList.add('invalid');
    } else {
        input.classList.remove('invalid');
    }
}

// Obtener datos de la matriz
function getMatrixData() {
    const matrix = [];
    for (let i = 0; i < currentSystemSize; i++) {
        const row = [];
        for (let j = 0; j < currentSystemSize; j++) {
            const value = document.getElementById(`matrix_${i}_${j}`).value.trim();
            row.push(value || '0');
        }
        matrix.push(row);
    }
    return matrix;
}

// Obtener datos del vector
function getVectorData() {
    const vector = [];
    for (let i = 0; i < currentSystemSize; i++) {
        const value = document.getElementById(`vector_${i}`).value.trim();
        vector.push(value || '0');
    }
    return vector;
}

// Cargar ejemplo predefinido
async function loadExample(exampleType) {
    try {
        const response = await fetch(`/example/${exampleType}`);
        const data = await response.json();
        
        if (data.success) {
            const example = data.example;
            
            // Ajustar tamaño del sistema si es necesario
            const exampleSize = example.matrix.length;
            if (exampleSize !== currentSystemSize) {
                document.getElementById('systemSize').value = exampleSize;
                currentSystemSize = exampleSize;
                generateMatrixInputs();
                generateVectorInputs();
            }
            
            // Cargar datos de la matriz
            for (let i = 0; i < exampleSize; i++) {
                for (let j = 0; j < exampleSize; j++) {
                    document.getElementById(`matrix_${i}_${j}`).value = example.matrix[i][j];
                }
            }
            
            // Cargar datos del vector
            for (let i = 0; i < exampleSize; i++) {
                document.getElementById(`vector_${i}`).value = example.vector[i];
            }
            
            showStatus(`📋 ${example.description} cargado correctamente`, 'success');
        }
    } catch (error) {
        showStatus('❌ Error al cargar el ejemplo', 'danger');
        console.error('Error loading example:', error);
    }
}

// Validar sistema
async function validateSystem() {
    const matrix = getMatrixData();
    const vector = getVectorData();
    
    // Validación básica del lado cliente
    if (!validateClientSide()) {
        return;
    }
    
    try {
        const response = await fetch('/validate', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                matrix: matrix,
                vector: vector
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            const opt = data.optimization;
            
            if (opt.can_optimize && opt.swaps_needed > 0) {
                showStatus(`🔧 ${opt.message}`, 'warning');
                showOptimizationAlert(opt);
            } else if (opt.can_optimize) {
                showStatus('✅ Sistema válido y diagonalmente dominante', 'success');
            } else {
                showStatus(`⚠️ ${opt.message}`, 'warning');
            }
        } else {
            showStatus(`❌ ${data.error}`, 'danger');
        }
        
    } catch (error) {
        showStatus('❌ Error de conexión al validar', 'danger');
        console.error('Validation error:', error);
    }
}

// Validación del lado cliente
function validateClientSide() {
    let hasErrors = false;
    
    // Validar matriz
    for (let i = 0; i < currentSystemSize; i++) {
        for (let j = 0; j < currentSystemSize; j++) {
            const input = document.getElementById(`matrix_${i}_${j}`);
            const value = input.value.trim();
            
            if (value === '' || isNaN(parseFloat(value))) {
                input.classList.add('invalid');
                hasErrors = true;
            } else {
                input.classList.remove('invalid');
            }
        }
    }
    
    // Validar vector
    for (let i = 0; i < currentSystemSize; i++) {
        const input = document.getElementById(`vector_${i}`);
        const value = input.value.trim();
        
        if (value === '' || isNaN(parseFloat(value))) {
            input.classList.add('invalid');
            hasErrors = true;
        } else {
            input.classList.remove('invalid');
        }
    }
    
    if (hasErrors) {
        showStatus('❌ Por favor corrige los valores resaltados en rojo', 'danger');
    }
    
    return !hasErrors;
}

// Resolver sistema
async function solveSystem() {
    if (!validateClientSide()) {
        return;
    }
    
    const matrix = getMatrixData();
    const vector = getVectorData();
    const tolerance = document.getElementById('tolerance').value || '1e-6';
    const maxIterations = document.getElementById('maxIterations').value || '100';
    
    // Mostrar modal de carga
    const loadingModal = new bootstrap.Modal(document.getElementById('loadingModal'));
    loadingModal.show();
    
    // Deshabilitar botón
    const solveBtn = document.getElementById('solveBtn');
    const originalText = solveBtn.innerHTML;
    solveBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Resolviendo...';
    solveBtn.disabled = true;
    
    try {
        const response = await fetch('/solve', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                matrix: matrix,
                vector: vector,
                tolerance: tolerance,
                max_iterations: maxIterations
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            // Procesar resultados
            iterationData = data.steps;
            currentIteration = 0;
            
            // Mostrar optimización si ocurrió
            if (data.optimization.was_optimized) {
                showOptimizationAlert(data.optimization);
                // Actualizar inputs con matriz optimizada
                updateInputsWithOptimizedData(data.optimization);
            }
            
            // Mostrar resultados
            displayResults(data);
            
            // Cambiar a tab de iteraciones
            const iterationsTab = new bootstrap.Tab(document.getElementById('iterations-tab'));
            iterationsTab.show();
            
            const result = data.result;
            if (result.converged) {
                showStatus(`✅ Sistema resuelto exitosamente en ${result.iterations} iteraciones`, 'success');
            } else {
                showStatus(`⚠️ Máximo de iteraciones alcanzado. Error final: ${result.final_error.toExponential(2)}`, 'warning');
            }
            
        } else {
            showStatus(`❌ ${data.error}`, 'danger');
        }
        
    } catch (error) {
        showStatus('❌ Error de conexión al resolver el sistema', 'danger');
        console.error('Solve error:', error);
    } finally {
        // Ocultar modal y restaurar botón
        loadingModal.hide();
        solveBtn.innerHTML = originalText;
        solveBtn.disabled = false;
    }
}

// Actualizar inputs con datos optimizados
function updateInputsWithOptimizedData(optimization) {
    if (!optimization.optimized_matrix || !optimization.optimized_vector) return;
    
    // Actualizar matriz
    for (let i = 0; i < currentSystemSize; i++) {
        for (let j = 0; j < currentSystemSize; j++) {
            document.getElementById(`matrix_${i}_${j}`).value = optimization.optimized_matrix[i][j];
        }
    }
    
    // Actualizar vector
    for (let i = 0; i < currentSystemSize; i++) {
        document.getElementById(`vector_${i}`).value = optimization.optimized_vector[i];
    }
}

// Mostrar alerta de optimización
function showOptimizationAlert(optimization) {
    const statusAlert = document.getElementById('statusAlert');
    statusAlert.className = 'alert alert-warning optimization-alert';
    statusAlert.style.display = 'block';
    
    let message = `🔧 ${optimization.message}`;
    
    if (optimization.swaps_made && optimization.swaps_made.length > 0) {
        message += '<div class="optimization-details">Intercambios realizados: ';
        optimization.swaps_made.forEach(swap => {
            message += `<span class="swap-item">Fila ${swap[0] + 1} ↔ Fila ${swap[1] + 1}</span> `;
        });
        message += '</div>';
    }
    
    document.getElementById('statusMessage').innerHTML = message;
}

// Mostrar resultados
function displayResults(data) {
    displayIterations();
    displayConvergenceChart(data.result.errors);
    displaySolution(data.result);
}

// Mostrar iteraciones
function displayIterations() {
    document.getElementById('iterationControls').style.display = 'flex';
    showIteration(0);
}

// Mostrar iteración específica
function showIteration(index) {
    if (!iterationData || index < 0 || index >= iterationData.length) return;
    
    currentIteration = index;
    const step = iterationData[index];
    
    // Actualizar información de iteración
    const iterationSteps = iterationData.filter(s => s.type === 'iteration');
    const iterationIndex = iterationSteps.findIndex(s => s === step);
    
    if (iterationIndex >= 0) {
        document.getElementById('iterationInfo').textContent = `Iteración ${iterationIndex + 1} / ${iterationSteps.length}`;
    }
    
    // Actualizar botones de navegación
    updateNavigationButtons();
    
    // Mostrar contenido de la iteración
    const content = document.getElementById('iterationContent');
    
    if (step.type === 'iteration') {
        content.innerHTML = generateIterationHTML(step);
    } else if (step.type === 'system') {
        content.innerHTML = generateSystemHTML(step);
    } else if (step.type === 'method') {
        content.innerHTML = generateMethodHTML(step);
    } else if (step.type === 'result') {
        content.innerHTML = generateResultHTML(step);
    }
    
    // Renderizar MathJax si es necesario
    if (window.MathJax) {
        MathJax.typesetPromise([content]);
    }
}

// Generar HTML para iteración
function generateIterationHTML(step) {
    let html = `
        <div class="iteration-card fade-in">
            <div class="iteration-header">
                <h4 class="iteration-title">🔄 Iteración ${step.iteration}</h4>
                <span class="error-badge">Error: ${step.error.toFixed(8)}</span>
            </div>
            
            <div class="calculation-grid">
    `;
    
    // Columna de cálculos
    html += '<div><h5>📝 Cálculos de Variables</h5>';
    step.calculations.forEach((calc, i) => {
        html += `
            <div class="calculation-item mb-3">
                <div class="variable-name">x${calc.variable + 1}</div>
                <div class="calculation-formula">${calc.formula}</div>
                <div class="calculation-result">= ${calc.result.toFixed(6)}</div>
            </div>
        `;
    });
    html += '</div>';
    
    // Columna de solución
    html += '<div><h5>🎯 Vector Solución</h5>';
    html += '<div class="solution-grid">';
    step.solution.forEach((value, i) => {
        html += `
            <div class="solution-item">
                <div class="solution-variable">x${i + 1}</div>
                <div class="solution-value">${value.toFixed(6)}</div>
            </div>
        `;
    });
    html += '</div></div>';
    
    html += '</div></div>';
    return html;
}

// Generar HTML para sistema original
function generateSystemHTML(step) {
    return `
        <div class="iteration-card fade-in">
            <div class="iteration-header">
                <h4 class="iteration-title">📋 ${step.title}</h4>
            </div>
            <p class="mb-3">${step.content}</p>
            <div class="row">
                <div class="col-md-6">
                    <h6>Matriz A:</h6>
                    <div class="matrix-display">${formatMatrix(step.matrix_A)}</div>
                </div>
                <div class="col-md-6">
                    <h6>Vector b:</h6>
                    <div class="vector-display">${formatVector(step.vector_b)}</div>
                </div>
            </div>
        </div>
    `;
}

// Generar HTML para método
function generateMethodHTML(step) {
    return `
        <div class="iteration-card fade-in">
            <div class="iteration-header">
                <h4 class="iteration-title">🧮 ${step.title}</h4>
            </div>
            <p>${step.content}</p>
            <div class="bg-light p-3 rounded">
                $$x_i^{(k+1)} = \\frac{1}{a_{ii}}\\left(b_i - \\sum_{j=1}^{i-1}a_{ij}x_j^{(k+1)} - \\sum_{j=i+1}^{n}a_{ij}x_j^{(k)}\\right)$$
            </div>
        </div>
    `;
}

// Generar HTML para resultado
function generateResultHTML(step) {
    let statusIcon = step.converged ? '✅' : '⚠️';
    let statusText = step.converged ? 'Convergió exitosamente' : 'Máximas iteraciones alcanzadas';
    let statusClass = step.converged ? 'text-success' : 'text-warning';
    
    return `
        <div class="iteration-card fade-in">
            <div class="iteration-header">
                <h4 class="iteration-title">🏆 ${step.title}</h4>
                <span class="badge bg-${step.converged ? 'success' : 'warning'} fs-6">${statusIcon} ${statusText}</span>
            </div>
            
            <div class="row mb-4">
                <div class="col-md-4 text-center">
                    <div class="h3 ${statusClass}">${step.iterations}</div>
                    <small class="text-muted">Iteraciones</small>
                </div>
                <div class="col-md-4 text-center">
                    <div class="h3 text-info">${step.final_error.toExponential(2)}</div>
                    <small class="text-muted">Error Final</small>
                </div>
                <div class="col-md-4 text-center">
                    <div class="h3 ${statusClass}">${statusIcon}</div>
                    <small class="text-muted">Estado</small>
                </div>
            </div>
            
            <h5>🎯 Solución Final:</h5>
            <div class="solution-grid">
                ${step.solution.map((value, i) => `
                    <div class="solution-item">
                        <div class="solution-variable">x${i + 1}</div>
                        <div class="solution-value">${value.toFixed(6)}</div>
                    </div>
                `).join('')}
            </div>
        </div>
    `;
}

// Formatear matriz para mostrar
function formatMatrix(matrix) {
    return `<pre class="matrix-display">${matrix.map(row => 
        '[' + row.map(val => val.toFixed(2).padStart(8)).join(' ') + ']'
    ).join('\n')}</pre>`;
}

// Formatear vector para mostrar
function formatVector(vector) {
    return `<pre class="vector-display">[${vector.map(val => val.toFixed(2)).join('\n ')}]</pre>`;
}

// Actualizar botones de navegación
function updateNavigationButtons() {
    const iterationSteps = iterationData.filter(s => s.type === 'iteration');
    const currentIterationIndex = iterationSteps.findIndex(s => iterationData.indexOf(s) === currentIteration);
    const totalIterations = iterationSteps.length;
    
    document.getElementById('firstBtn').disabled = currentIterationIndex <= 0;
    document.getElementById('prevBtn').disabled = currentIterationIndex <= 0;
    document.getElementById('nextBtn').disabled = currentIterationIndex >= totalIterations - 1;
    document.getElementById('lastBtn').disabled = currentIterationIndex >= totalIterations - 1;
}

// Navegación entre iteraciones
function prevIteration() {
    const iterationSteps = iterationData.filter(s => s.type === 'iteration');
    const currentIterationIndex = iterationSteps.findIndex(s => iterationData.indexOf(s) === currentIteration);
    
    if (currentIterationIndex > 0) {
        const prevStepIndex = iterationData.indexOf(iterationSteps[currentIterationIndex - 1]);
        showIteration(prevStepIndex);
    }
}

function nextIteration() {
    const iterationSteps = iterationData.filter(s => s.type === 'iteration');
    const currentIterationIndex = iterationSteps.findIndex(s => iterationData.indexOf(s) === currentIteration);
    
    if (currentIterationIndex < iterationSteps.length - 1) {
        const nextStepIndex = iterationData.indexOf(iterationSteps[currentIterationIndex + 1]);
        showIteration(nextStepIndex);
    }
}

function showLastIteration() {
    const iterationSteps = iterationData.filter(s => s.type === 'iteration');
    if (iterationSteps.length > 0) {
        const lastStepIndex = iterationData.indexOf(iterationSteps[iterationSteps.length - 1]);
        showIteration(lastStepIndex);
    }
}

// Mostrar gráfico de convergencia
function displayConvergenceChart(errors) {
    const ctx = document.getElementById('convergenceChart');
    
    // Destruir gráfico anterior si existe
    if (convergenceChart) {
        convergenceChart.destroy();
    }
    
    // Mostrar métricas y ocultar placeholder
    document.getElementById('convergenceMetrics').style.display = 'flex';
    document.getElementById('convergencePlaceholder').style.display = 'none';
    ctx.style.display = 'block';
    
    // Crear nuevo gráfico
    convergenceChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: errors.map((_, i) => `Iter ${i + 1}`),
            datasets: [{
                label: 'Error',
                data: errors,
                borderColor: '#0d6efd',
                backgroundColor: 'rgba(13, 110, 253, 0.1)',
                borderWidth: 2,
                pointRadius: 4,
                pointHoverRadius: 6,
                tension: 0.1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    type: 'logarithmic',
                    title: {
                        display: true,
                        text: 'Error (escala logarítmica)'
                    },
                    grid: {
                        alpha: 0.3
                    }
                },
                x: {
                    title: {
                        display: true,
                        text: 'Iteración'
                    }
                }
            },
            plugins: {
                title: {
                    display: true,
                    text: '📈 Convergencia del Método de Gauss-Seidel'
                },
                legend: {
                    display: false
                }
            },
            animation: {
                duration: 1000,
                easing: 'easeInOutCubic'
            }
        }
    });
    
    // Actualizar métricas
    if (errors.length > 0) {
        document.getElementById('currentError').textContent = errors[errors.length - 1].toExponential(2);
        document.getElementById('totalIterations').textContent = errors.length;
        
        if (errors.length > 1) {
            const rate = errors[errors.length - 2] / errors[errors.length - 1];
            document.getElementById('convergenceRate').textContent = rate.toFixed(2);
        } else {
            document.getElementById('convergenceRate').textContent = 'N/A';
        }
    }
}

// Mostrar solución final
function displaySolution(result) {
    let html = `
        <div class="text-center mb-4">
            <h3 class="${result.converged ? 'text-success' : 'text-warning'}">
                ${result.converged ? '✅ ¡Sistema Resuelto Exitosamente!' : '⚠️ Convergencia No Alcanzada'}
            </h3>
        </div>
        
        <div class="row mb-4">
            <div class="col-md-3 text-center">
                <div class="h4 text-primary">${result.iterations}</div>
                <small class="text-muted">Iteraciones</small>
            </div>
            <div class="col-md-3 text-center">
                <div class="h4 text-info">${result.final_error.toExponential(2)}</div>
                <small class="text-muted">Error Final</small>
            </div>
            <div class="col-md-3 text-center">
                <div class="h4 ${result.converged ? 'text-success' : 'text-warning'}">
                    ${result.converged ? '✅' : '⚠️'}
                </div>
                <small class="text-muted">Convergencia</small>
            </div>
            <div class="col-md-3 text-center">
                <div class="h4 text-secondary">${result.solution.length}</div>
                <small class="text-muted">Variables</small>
            </div>
        </div>
        
        <h5 class="text-center mb-3">🎯 Solución del Sistema</h5>
        <div class="solution-grid">
    `;
    
    result.solution.forEach((value, i) => {
        html += `
            <div class="solution-item">
                <div class="solution-variable">x${i + 1}</div>
                <div class="solution-value">${value.toFixed(6)}</div>
            </div>
        `;
    });
    
    html += '</div>';
    
    document.getElementById('solutionContent').innerHTML = html;
}

// Limpiar todo
function clearAll() {
    // Limpiar inputs
    document.querySelectorAll('.matrix-input, .vector-input').forEach(input => {
        input.value = '';
        input.classList.remove('invalid');
    });
    
    // Limpiar resultados
    clearResults();
    
    showStatus('🧹 Todos los campos han sido limpiados', 'info');
}

// Limpiar resultados
function clearResults() {
    iterationData = [];
    currentIteration = 0;
    
    // Ocultar controles de iteración
    document.getElementById('iterationControls').style.display = 'none';
    
    // Limpiar contenido de iteraciones
    document.getElementById('iterationContent').innerHTML = `
        <div class="text-center text-muted py-5">
            <i class="fas fa-calculator fa-3x mb-3"></i>
            <p>Resuelve un sistema para ver las iteraciones paso a paso</p>
        </div>
    `;
    
    // Limpiar gráfico de convergencia
    if (convergenceChart) {
        convergenceChart.destroy();
        convergenceChart = null;
    }
    
    document.getElementById('convergenceMetrics').style.display = 'none';
    document.getElementById('convergencePlaceholder').style.display = 'block';
    document.getElementById('convergenceChart').style.display = 'none';
    
    // Limpiar solución
    document.getElementById('solutionContent').innerHTML = `
        <div class="text-center text-muted py-5">
            <i class="fas fa-trophy fa-3x mb-3"></i>
            <p>La solución final aparecerá aquí</p>
        </div>
    `;
}

// Mostrar status
function showStatus(message, type) {
    const statusAlert = document.getElementById('statusAlert');
    statusAlert.className = `alert alert-${type}`;
    statusAlert.style.display = 'block';
    document.getElementById('statusMessage').innerHTML = message;
    
    // Auto-ocultar después de 5 segundos para mensajes de éxito
    if (type === 'success') {
        setTimeout(() => {
            statusAlert.style.display = 'none';
        }, 5000);
    }
}
