# 🌐 Gauss-Seidel Web App - Información de Despliegue

## 📦 Contenido del Paquete

### 📄 Archivos Principales:
- web_app.py          # Aplicación Flask principal
- .htaccess           # Configuración Apache
- requirements_web.txt # Dependencias Python

### 📁 Directorios:
- templates/          # Plantillas HTML
- static/            # CSS, JS y recursos estáticos
- solver/            # Algoritmo de Gauss-Seidel
- utils/             # Validadores y utilidades

## 🚀 Configuración Rápida en cPanel

1. **Subir archivos:**
   - Accede a cPanel > File Manager
   - Ve a public_html/
   - Sube todos los archivos manteniendo la estructura

2. **Configurar Python App:**
   - cPanel > Python App
   - Application root: /public_html
   - Startup file: web_app.py
   - Entry point: application

3. **Instalar dependencias:**
   ```bash
   pip install -r requirements_web.txt
   ```

4. **Probar:**
   - Accede a tu dominio
   - Carga un ejemplo y resuelve un sistema

## 🔧 URLs de la Aplicación

- `/` - Interfaz principal
- `/solve` - API para resolver sistemas
- `/validate` - API para validar entrada
- `/example/1,2,3` - Ejemplos predefinidos

## 📞 Soporte

Consulta DESPLIEGUE_GODADDY.md para instrucciones detalladas.
